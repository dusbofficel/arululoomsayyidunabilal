Place AkramUnicode.ttf and JameelNastaleeq.ttf here.
If you want, I can add them if you upload the font files.