
/* Simplified but functional React single-file app for Darul Uloom Sayyiduna Bilal.
   This version implements the multilingual single-page layout, slideshow, admin login,
   PDF upload (stored in localStorage), and results grouped by term/department/year.
   Place this file at src/components/DarulUloomBilal_AdminEnhanced.jsx
*/
import React, { useEffect, useRef, useState } from 'react';

const SLIDES = [
  '/assets/WhatsApp Image 2025-11-08 at 15.06.24_3c64e6c6.jpg',
  '/assets/WhatsApp Image 2025-11-08 at 15.06.24_a7c5d376.jpg',
  '/assets/WhatsApp Image 2025-11-08 at 15.06.25_9ee1cd81.jpg',
  '/assets/WhatsApp Image 2025-11-08 at 15.06.25_a0c35d1b.jpg',
  '/assets/WhatsApp Image 2025-11-08 at 15.06.25_bc1eb8bd.jpg'
];
const LOGO = '/assets/لوگو دارالعلوم سیدنا بلال .-1.png';
const LOCAL_KEY = 'dulb_results_v2';
const ADMIN_PASS = 'bilaladmin123';

const translations = {
  ur: { name:'دارالعلوم سیدنا بلالؓ', address:'مقام ناکھنول، تحصیل تجارہ، ضلع خیرتھل، راجستھان — پن کوڈ: 301707', menu:['ہوم','تعارف','تعلیمی سرگرمیاں','دیگر نشاطات','نصابِ تعلیم','شعبہ جات','جدید داخلے','نتائج'], intro_text:'دارالعلوم سیدنا بلالؓ ایک روایتی مدرسہ ہے جو دینی و عصری تعلیم کا امتزاج پیش کرتا ہے۔', admissions_title:'جدید داخلے', results_title:'نتائج', midterm:'ششماہی', annual:'سالانہ', contact_title:'رابطہ', donate:'چندہ دیں', footer:'© دارالعلوم سیدنا بلالؓ — تمام حقوق محفوظ' },
  hi: { name:'दारुल उलूम सय्यदना बिल्लाल (रज़ि॰)', address:'स्थान नाखनोल, तहसील तिजारा, जिला खैरथल, राजस्थान — पिन कोड: 301707', menu:['होम','परिचय','शैक्षणिक गतिविधियाँ','अन्य गतिविधियाँ','पाठ्यक्रम','विभाग','नवीन प्रवेश','परिणाम'], intro_text:'दारुल उलूम...', admissions_title:'नवीन प्रवेश', results_title:'परिणाम', midterm:'मध्यावधि', annual:'वार्षिक', contact_title:'संपर्क', donate:'दान करें', footer:'© दारुल उलूम...' },
  en: { name:'Darul Uloom Sayyiduna Bilal (RZ)', address:'Nakhnaul, Tehsil Tijara, District Khairthal, Rajasthan — Pincode: 301707', menu:['Home','Introduction','Educational Activities','Other Activities','Curriculum','Departments','Admissions','Results'], intro_text:'Darul Uloom Sayyiduna Bilal is a traditional madrasa emphasizing both religious and contemporary education.', admissions_title:'Admissions', results_title:'Results', midterm:'Midterm', annual:'Annual', contact_title:'Contact', donate:'Donate', footer:'© Darul Uloom Sayyiduna Bilal — All rights reserved' }
};

function readStorage(){ try{ const raw = localStorage.getItem(LOCAL_KEY); return raw ? JSON.parse(raw) : []; }catch(e){return [];} }
function writeStorage(arr){ localStorage.setItem(LOCAL_KEY, JSON.stringify(arr)); }

export default function DarulUloomBilalAdmin(){
  const [lang, setLang] = useState('ur');
  const [slide, setSlide] = useState(0);
  const timerRef = useRef(null);
  const [results, setResults] = useState(readStorage());
  const [auth, setAuth] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [password, setPassword] = useState('');
  const [newR, setNewR] = useState({ term:'midterm', year:(new Date()).getFullYear(), dept:'nazerah', title:'', fileData:'', fileName:'', externalLink:'' });

  useEffect(()=>{
    timerRef.current = setInterval(()=> setSlide(s=> (s+1)%SLIDES.length), 3000);
    return ()=> clearInterval(timerRef.current);
  },[]);

  useEffect(()=> writeStorage(results),[results]);

  useEffect(()=>{
    if(lang==='ur'){ document.documentElement.dir='rtl'; document.documentElement.style.fontFamily = "AkramUnicode, JameelNastaleeq, 'Rubik', sans-serif"; }
    else { document.documentElement.dir='ltr'; document.documentElement.style.fontFamily = "'Rubik', system-ui, sans-serif"; }
  },[lang]);

  const tryLogin = ()=>{
    if(password === ADMIN_PASS){ setAuth(true); setShowLogin(false); setPassword(''); alert('Admin logged in'); }
    else alert('Invalid password');
  };
  const logout = ()=> setAuth(false);

  const handleFile = (file)=>{
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (e)=> setNewR(r=> ({ ...r, fileData: e.target.result, fileName: file.name, externalLink: '' }));
    reader.readAsDataURL(file);
  };

  const addResult = ()=>{
    if(!auth){ alert('Login as admin'); setShowLogin(true); return; }
    if(!newR.title) { alert('Enter title'); return; }
    const entry = {...newR, id: Date.now()};
    setResults(prev=> [entry, ...prev]);
    setNewR({ term:newR.term, year:newR.year, dept:newR.dept, title:'', fileData:'', fileName:'', externalLink:'' });
  };

  const deleteResult = (id)=>{
    if(!auth){ alert('Login as admin'); setShowLogin(true); return; }
    if(!window.confirm('Delete?')) return;
    setResults(prev=> prev.filter(r=> r.id !== id));
  };

  const grouped = results.reduce((acc,r)=>{
    acc[r.term]=acc[r.term]||{};
    acc[r.term][r.dept]=acc[r.term][r.dept]||{};
    acc[r.term][r.dept][r.year]=acc[r.term][r.dept][r.year]||[];
    acc[r.term][r.dept][r.year].push(r);
    return acc;
  },{});

  const t = translations[lang];

  return (
    <div className="min-h-screen bg-green-50 text-gray-900">
      <header className="bg-gradient-to-r from-emerald-700 to-emerald-800 text-white">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <img src={LOGO} alt="logo-left" className="w-20 h-20 object-contain" />
            <div className="text-center">
              <div style={{fontFamily:'AkramUnicode'}} className="text-3xl font-bold leading-tight">{t.name}</div>
              <div style={{fontFamily:'JameelNastaleeq'}} className="text-sm mt-1">{t.address}</div>
            </div>
            <img src={LOGO} alt="logo-right" className="w-20 h-20 object-contain" />
          </div>
          <div className="mt-4 flex items-center justify-end gap-2">
            <div className="flex items-center gap-2">
              <button onClick={()=>setLang('ur')} className={`px-3 py-1 rounded ${lang==='ur' ? 'bg-white text-emerald-800 font-bold':'text-white/90 border border-white/20'}`}>اردو</button>
              <button onClick={()=>setLang('hi')} className={`px-3 py-1 rounded ${lang==='hi' ? 'bg-white text-emerald-800 font-bold':'text-white/90 border border-white/20'}`}>हिंदी</button>
              <button onClick={()=>setLang('en')} className={`px-3 py-1 rounded ${lang==='en' ? 'bg-white text-emerald-800 font-bold':'text-white/90 border border-white/20'}`}>English</button>
            </div>
          </div>
          <div className="mt-4 bg-white rounded-xl p-3 shadow-lg flex items-center justify-between">
            <nav className="flex gap-2 flex-wrap">
              {t.menu.map((m,i)=> (
                <a key={i} href={`#${['home','intro','activities','others','curriculum','departments','admissions','results'][i]}`} className="px-3 py-2 rounded hover:bg-emerald-50 text-emerald-700 font-semibold">{m}</a>
              ))}
            </nav>
            <div className="flex items-center gap-2">
              {!auth ? <button onClick={()=>setShowLogin(true)} className="px-3 py-2 bg-emerald-700 text-white rounded">Admin Login</button> : <><span className="text-sm">Admin</span><button onClick={logout} className="px-3 py-2 bg-white text-emerald-800 rounded">Logout</button></>}
            </div>
          </div>
        </div>
      </header>

      <section id="home" className="max-w-6xl mx-auto px-4 -mt-8">
        <div className="relative rounded-xl overflow-hidden shadow-xl">
          <div className="h-64 md:h-96 w-full relative">
            {SLIDES.map((s,i)=> (
              <img key={s} src={s} alt={`slide-${i}`} className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-700 ${i===slide? 'opacity-100 z-10':'opacity-0 z-0'}`} />
            ))}
            <div className="absolute inset-0 bg-black/30 flex items-center">
              <div className="max-w-3xl mx-auto text-center text-white px-4">
                <h1 className="text-3xl md:text-4xl font-bold">{t.name}</h1>
                <p className="mt-2">{t.intro_text}</p>
                <div className="mt-4 flex gap-2 justify-center">
                  <a href="#admissions" className="bg-emerald-600 px-4 py-2 rounded shadow font-semibold">{t.admissions_title}</a>
                  <a href="#results" className="bg-white text-emerald-700 px-4 py-2 rounded shadow font-semibold">{t.results_title}</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <main className="max-w-6xl mx-auto px-4 py-8 grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <section id="intro" className="bg-white rounded-lg p-6 shadow"><h2 className="text-2xl text-emerald-800 font-bold">{t.menu[1]}</h2><p className="mt-3 text-gray-700">{t.intro_text}</p></section>
          <section id="activities" className="bg-white rounded-lg p-6 shadow"><h2 className="text-2xl text-emerald-800 font-bold">{t.menu[2]}</h2><p className="mt-3 text-gray-700">Activities details here.</p></section>
          <section id="curriculum" className="bg-white rounded-lg p-6 shadow"><h2 className="text-2xl text-emerald-800 font-bold">{t.menu[4]}</h2>
            <div className="mt-4 space-y-2">{['ناظرہ','تحفیظ','فارسی','عربی اول','عربی دوم','عربی سوم','عربی چہارم','عربی پنجم'].map((it,i)=>(<details key={i} className="border rounded p-3"><summary className="cursor-pointer font-semibold">{it}</summary><div className="mt-2 text-gray-700">نصاب کی تفصیل یہاں شامل کریں۔</div></details>))}</div>
          </section>
          <section id="departments" className="bg-white rounded-lg p-6 shadow"><h2 className="text-2xl text-emerald-800 font-bold">{t.menu[5]}</h2><div className="mt-4 space-y-2">{['قرآن و تجوید','تجوید و حدیث','ادبِ عربی','افتاء','عصری تعلیم'].map((d,i)=>(<details key={i} className="border rounded p-3"><summary className="cursor-pointer font-semibold">{d}</summary><div className="mt-2 text-gray-700">تفصیل یہاں درج کریں۔</div></details>))}</div></section>
          <section id="admissions" className="bg-white rounded-lg p-6 shadow"><h2 className="text-2xl text-emerald-800 font-bold">{t.admissions_title}</h2><p className="mt-2 text-gray-700">Admission form below.</p>
            <form className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3" onSubmit={(e)=>{e.preventDefault(); alert('فارم جمع ہو گیا'); e.target.reset();}}>
              <input placeholder={lang==='ur'?'طالب علم کا نام':'Student Name'} className="border rounded p-2" required />
              <input placeholder={lang==='ur'?'ولد/دختر':'Parent/Guardian'} className="border rounded p-2" required />
              <input type="number" placeholder={lang==='ur'?'عمر':'Age'} className="border rounded p-2" required />
              <input placeholder={lang==='ur'?'رابطہ نمبر':'Phone'} className="border rounded p-2" required />
              <select className="border rounded p-2"><option>{lang==='ur'?'پروگرام منتخب کریں':'Select Program'}</option><option>Hifz</option><option>Studies</option></select>
              <textarea placeholder={lang==='ur'?'مختصر نوٹس':'Short Note'} className="border rounded p-2 md:col-span-2" />
              <button className="bg-emerald-700 text-white px-4 py-2 rounded md:col-span-2">{lang==='ur'?'جمع کریں':'Submit'}</button>
            </form>
          </section>

          <section id="results" className="bg-white rounded-lg p-6 shadow">
            <div className="flex items-center justify-between"><h2 className="text-2xl text-emerald-800 font-bold">{t.results_title}</h2><div className="text-sm text-gray-600">{auth? 'Admin: signed in':'Visitor mode'}</div></div>
            <p className="mt-2 text-gray-700">شعبہ وار نتائج یہاں دکھیں گے۔</p>

            {auth && (
              <div className="mt-4 border rounded p-4 bg-emerald-50">
                <h4 className="font-semibold">Admin: Add Result</h4>
                <div className="mt-3 grid grid-cols-1 md:grid-cols-4 gap-2">
                  <select value={newR.term} onChange={(e)=>setNewR(s=>({...s, term:e.target.value}))} className="border rounded p-2"><option value="midterm">{t.midterm}</option><option value="annual">{t.annual}</option></select>
                  <input type="number" value={newR.year} onChange={(e)=>setNewR(s=>({...s, year:Number(e.target.value)}))} className="border rounded p-2" />
                  <select value={newR.dept} onChange={(e)=>setNewR(s=>({...s, dept:e.target.value}))} className="border rounded p-2"><option value="nazerah">ناظرہ</option><option value="hifz">تحفیظ</option></select>
                  <input placeholder="عنوان درج کریں" value={newR.title} onChange={(e)=>setNewR(s=>({...s, title:e.target.value}))} className="border rounded p-2" />
                  <input type="file" accept="application/pdf" onChange={(e)=>handleFile(e.target.files[0])} className="border rounded p-2" />
                  <input placeholder="Or external link" value={newR.externalLink} onChange={(e)=>setNewR(s=>({...s, externalLink:e.target.value, fileData:'', fileName:''}))} className="border rounded p-2 md:col-span-3" />
                  <div className="md:col-span-4 flex items-center gap-2"><button onClick={addResult} className="bg-emerald-700 text-white rounded px-3 py-2">Add Result</button><button onClick={()=>setNewR({term:newR.term, year:newR.year, dept:newR.dept, title:'', fileData:'', fileName:'', externalLink:''})} className="border rounded px-3 py-2">Reset</button></div>
                </div>
              </div>
            )}

            {!auth && (<div className="mt-3 text-sm text-gray-600">If you are admin, click <button onClick={()=>setShowLogin(true)} className="underline text-emerald-700">here</button> to sign in.</div>)}

            <div className="mt-4 space-y-3">
              {Object.keys(grouped).length===0 && <div className="text-gray-600">No results uploaded yet.</div>}
              {Object.entries(grouped).map(([term,deps])=>(
                <div key={term} className="border rounded p-3">
                  <h4 className="font-semibold text-emerald-700">{term==='midterm'? t.midterm: t.annual}</h4>
                  <div className="mt-2 space-y-2">{Object.entries(deps).map(([dept,years])=>(
                    <div key={dept} className="pl-2">
                      <div className="font-semibold">{dept}</div>
                      <div className="mt-1 space-y-1">{Object.entries(years).map(([yr,arr])=>(
                        <div key={yr} className="pl-3"><div className="font-medium">{yr}</div>
                          <ul className="list-disc ml-5 mt-1">{arr.map(r=>(
                            <li key={r.id} className="flex items-center gap-3"><span className="truncate">{r.title}</span>{r.fileData && <a className="text-emerald-700 underline" href={r.fileData} download={r.fileName} target="_blank" rel="noreferrer">Download PDF</a>}{!r.fileData && r.externalLink && <a className="text-emerald-700 underline" href={r.externalLink} target="_blank" rel="noreferrer">View Link</a>}{auth && <button onClick={()=>deleteResult(r.id)} className="text-red-600">Delete</button>}</li>
                          ))}</ul></div>
                      </div>
                    </div>
                  ))}</div>
                </div>
              ))}
            </div>

          </section>

        </div>

        <aside className="space-y-6">
          <div id="contact" className="bg-white rounded-lg p-4 shadow">
            <h3 className="font-semibold text-emerald-800">{t.contact_title}</h3>
            <p className="mt-2 text-gray-700">{t.address}</p>
            <p className="mt-2 text-gray-700">Phone: 9024352763 / 9309026986</p>
            <p className="mt-2"><a href="mailto:dusb212@gmail.com" className="text-emerald-700 underline">dusb212@gmail.com</a></p>
          </div>

          <div className="bg-white rounded-lg p-4 shadow">
            <h3 className="font-semibold text-emerald-800">{t.donate}</h3>
            <p className="mt-2 text-gray-700">Bank details and online gateway will be added in the footer later.</p>
            <button className="mt-3 border rounded px-3 py-2">Donate</button>
          </div>

          <div className="bg-white rounded-lg p-4 shadow">
            <h3 className="font-semibold text-emerald-800">Quick Links</h3>
            <ul className="mt-2 space-y-1 text-gray-700"><li><a href="#admissions" className="underline">{t.admissions_title}</a></li><li><a href="#results" className="underline">{t.results_title}</a></li><li><a href="#curriculum" className="underline">{t.menu[4]}</a></li></ul>
          </div>
        </aside>

      </main>

      <footer className="bg-white border-t mt-8 py-6"><div className="max-w-6xl mx-auto px-4 text-center text-gray-600">{t.footer}</div></footer>

      {showLogin && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded p-6 w-full max-w-md">
            <h3 className="font-semibold mb-2">Admin Login</h3>
            <p className="text-sm text-gray-600">Enter admin password to manage results.</p>
            <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} className="border rounded p-2 w-full mt-3" placeholder="Password" />
            <div className="mt-4 flex justify-end gap-2"><button onClick={()=> setShowLogin(false)} className="px-3 py-2 border rounded">Cancel</button><button onClick={tryLogin} className="px-3 py-2 bg-emerald-700 text-white rounded">Login</button></div>
          </div>
        </div>
      )}

    </div>
  );
}
