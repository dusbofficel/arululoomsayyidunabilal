DarulUloomBilal_Website - GitHub-ready package
=============================================

Contents:
- src/components/DarulUloomBilal_AdminEnhanced.jsx  (React component, enhanced admin/results)
- public/assets/ (logo and slideshow images)
- public/fonts/ (placeholders for AkramUnicode & JameelNastaleeq - add actual font files here)
- README.md (this file)
- INSTRUCTIONS.txt (step-by-step to run locally and deploy to GitHub Pages)

Notes:
- This package contains the React component prepared for Create React App. To run locally,
  create a CRA project and replace/add the files as instructed in INSTRUCTIONS.txt.
- Admin login is client-side (password: bilaladmin123). For production, set up server-side auth.
- Results (PDFs) stored in browser localStorage. For large/secure storage, move to Firebase/S3.